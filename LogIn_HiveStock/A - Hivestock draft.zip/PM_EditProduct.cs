﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySqlConnector;
using System.IO;

namespace LogIn_HiveStock
{
    public partial class  PM_EditProduct : Form
    {
        private readonly string connectionString =
            ConfigurationManager.ConnectionStrings["HiveStockDb"].ConnectionString;

        private readonly int startProductId;
        private int loadedProductId = 0;   // the product currently in the boxes (0 = none)
        private int loadedQuantity = 0;
        public PM_EditProduct() : this(0) { }
        private string selectedImagePath = "";   // a NEW picture chosen with ADD IMAGE ("" = keep the current one)
        private PictureBox imagePreview;
        private Label imageNameLabel;

        public PM_EditProduct(int productId)
        {
            InitializeComponent();
            BuildImageControls();
            startProductId = productId;

            EPPrice_UpDown.Maximum = 100000;
            EPPrice_UpDown.DecimalPlaces = 2;
            EPQuantity_UpDown.Maximum = 100000;

            EPStatus_Dropdown.Enabled = false;   // worked out from the quantity by the database
            EPQuantity_UpDown.ValueChanged += (s, e) => ShowStatusFromQuantity();

            EPProductID_TextBox.KeyDown += EPProductID_TextBox_KeyDown;
            EPProductID_TextBox.Leave += (s, e) => LoadProduct(true);   // quiet check when leaving the box
            this.Shown += (s, e) =>
            {
                if (startProductId > 0)
                {
                    EPProductID_TextBox.Text = startProductId.ToString();
                    LoadProduct(false);
                }
                else
                {
                    EPProductID_TextBox.Focus();
                }
            };
        }

        private void ShowStatusFromQuantity()
        {
            int qty = (int)EPQuantity_UpDown.Value;
            EPStatus_Dropdown.SelectedIndex = qty == 0 ? 3 : qty < 20 ? 2 : 1;   // Out / Low / On Stock
        }

        private void BuildImageControls()
        {
            const int extra = 100;
            this.ClientSize = new Size(this.ClientSize.Width, this.ClientSize.Height + extra);
            EPInfo_Panel.Height += extra;
            EPCancel_Button.Top += extra;
            EPCreate_Button.Top += extra;

            Label caption = new Label();
            caption.AutoSize = true;
            caption.BackColor = Color.Transparent;
            caption.Font = new Font("Malgun Gothic", 9F, FontStyle.Bold);
            caption.ForeColor = Color.DimGray;
            caption.Text = "Image";
            caption.Location = new Point(57, 268);

            imagePreview = new PictureBox();
            imagePreview.Location = new Point(106, 262);
            imagePreview.Size = new Size(120, 95);
            imagePreview.SizeMode = PictureBoxSizeMode.Zoom;
            imagePreview.BackColor = Color.White;
            imagePreview.BorderStyle = BorderStyle.FixedSingle;

            Guna.UI2.WinForms.Guna2Button addImage = new Guna.UI2.WinForms.Guna2Button();
            addImage.Text = "ADD IMAGE";
            addImage.BorderRadius = 5;
            addImage.FillColor = Color.FromArgb(18, 77, 28);
            addImage.ForeColor = Color.White;
            addImage.Font = new Font("Malgun Gothic", 9.75F, FontStyle.Bold);
            addImage.Cursor = Cursors.Hand;
            addImage.BackColor = Color.Transparent;
            addImage.Location = new Point(241, 262);
            addImage.Size = new Size(127, 36);
            addImage.Click += AddImage_Click;

            imageNameLabel = new Label();
            imageNameLabel.AutoSize = false;
            imageNameLabel.AutoEllipsis = true;
            imageNameLabel.BackColor = Color.Transparent;
            imageNameLabel.ForeColor = Color.DimGray;
            imageNameLabel.Font = new Font("Malgun Gothic", 8.25F);
            imageNameLabel.Text = "Load a product to see its picture";
            imageNameLabel.Location = new Point(241, 306);
            imageNameLabel.Size = new Size(330, 20);

            EPInfo_Panel.Controls.Add(caption);
            EPInfo_Panel.Controls.Add(imagePreview);
            EPInfo_Panel.Controls.Add(addImage);
            EPInfo_Panel.Controls.Add(imageNameLabel);
        }

        // The preview always holds its own copy, so disposing it never harms a shared picture.
        private void SetPreview(Image copy)
        {
            Image previous = imagePreview.Image;
            imagePreview.Image = copy;
            if (previous != null) previous.Dispose();
        }

        private void AddImage_Click(object sender, EventArgs e)
        {
            if (loadedProductId == 0)
            {
                ShowWarning("Load a product first (type its Product ID and press Enter).");
                return;
            }

            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Title = "Choose a new product picture";
                dialog.Filter = "Image files (*.jpg;*.jpeg;*.png;*.bmp;*.gif)|*.jpg;*.jpeg;*.png;*.bmp;*.gif";
                dialog.CheckFileExists = true;

                if (dialog.ShowDialog(this) != DialogResult.OK) return;

                try
                {
                    Image loaded;
                    using (FileStream stream = new FileStream(dialog.FileName, FileMode.Open, FileAccess.Read))
                    using (Image temp = Image.FromStream(stream))
                    {
                        loaded = new Bitmap(temp);
                    }

                    SetPreview(loaded);
                    selectedImagePath = dialog.FileName;
                    imageNameLabel.Text = "New picture: " + Path.GetFileName(dialog.FileName);
                }
                catch (Exception)
                {
                    MessageBox.Show("That file could not be opened as a picture. Please choose a JPG, PNG, BMP or GIF.",
                        "Invalid File", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        // Enter = search for the product.
        private void EPProductID_TextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                e.Handled = true;
                LoadProduct(false);
            }
        }

        // Fills the boxes from the database. quiet = no messages when nothing is found.
        private bool LoadProduct(bool quiet)
        {
            int id;
            if (!int.TryParse(EPProductID_TextBox.Text.Trim(), out id) || id < 1)
            {
                if (!quiet) ShowWarning("Enter a valid Product ID, then press Enter.");
                return false;
            }

            if (id == loadedProductId) return true;   // already showing this product

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    using (MySqlCommand cmd = new MySqlCommand(
                        @"SELECT product_name, description, price, category_id, stock_qty, stock_status, product_img
                          FROM product WHERE product_id = @id", conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);

                        using (MySqlDataReader r = cmd.ExecuteReader())
                        {
                            if (!r.Read())
                            {
                                if (!quiet) ShowWarning("No product found with Product ID " + id + ".");
                                ClearFields();
                                return false;
                            }

                            EPProductName_TextBox.Text = r["product_name"].ToString().Trim();
                            EPDescription_TextBox.Text = r["description"].ToString().Trim();

                            decimal price = Convert.ToDecimal(r["price"]);
                            EPPrice_UpDown.Value = Math.Max(EPPrice_UpDown.Minimum, Math.Min(EPPrice_UpDown.Maximum, price));

                            int qty = Convert.ToInt32(r["stock_qty"]);
                            EPQuantity_UpDown.Value = Math.Max(EPQuantity_UpDown.Minimum, Math.Min(EPQuantity_UpDown.Maximum, qty));

                            int cat = Convert.ToInt32(r["category_id"]);
                            EPCategory_Dropdown.SelectedIndex = (cat >= 1 && cat <= 3) ? cat : 0;

                            switch (r["stock_status"].ToString().Trim().ToLower())
                            {
                                case "in stock":
                                case "on stock": EPStatus_Dropdown.SelectedIndex = 1; break;
                                case "low stock": EPStatus_Dropdown.SelectedIndex = 2; break;
                                case "out of stock":
                                case "no stock": EPStatus_Dropdown.SelectedIndex = 3; break;
                                default: EPStatus_Dropdown.SelectedIndex = 0; break;
                            }

                            string imgName = r["product_img"] == DBNull.Value ? null : r["product_img"].ToString().Trim();
                            Image current = ProductImages.Get(id, imgName);
                            SetPreview(current == null ? null : new Bitmap(current));   // a copy, not the shared picture
                            selectedImagePath = "";
                            imageNameLabel.Text = current == null
                                ? "No picture yet. Press ADD IMAGE to add one."
                                : "Current picture (press ADD IMAGE to replace it)";

                            loadedQuantity = qty;
                            EPProductID_TextBox.ReadOnly = true;   // the ID can no longer be changed
                            ShowStatusFromQuantity();
                            loadedProductId = id;
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                if (!quiet)
                    MessageBox.Show("Could not load the product: " + ex.Message,
                        "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        private void ClearFields()
        {
            loadedProductId = 0;
            EPProductName_TextBox.Clear();
            EPDescription_TextBox.Clear();
            EPPrice_UpDown.Value = EPPrice_UpDown.Minimum;
            EPQuantity_UpDown.Value = EPQuantity_UpDown.Minimum;
            EPCategory_Dropdown.SelectedIndex = 0;
            EPStatus_Dropdown.SelectedIndex = 0;
            loadedQuantity = 0;
            EPProductID_TextBox.ReadOnly = false;

            SetPreview(null);
            selectedImagePath = "";
            imageNameLabel.Text = "Load a product to see its picture";
        }

        private void EPCancel_Button_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        // The green button: saves the changes to the product that was loaded.
        private void EPCreate_Button_Click(object sender, EventArgs e)
        {
            if (loadedProductId == 0)
            {
                ShowWarning("Type a Product ID and press Enter to load the product first.");
                return;
            }

            string name = EPProductName_TextBox.Text.Trim();
            string description = EPDescription_TextBox.Text.Trim();
            decimal price = EPPrice_UpDown.Value;
            int quantity = (int)EPQuantity_UpDown.Value;
            int categoryId = EPCategory_Dropdown.SelectedIndex;   // 1 Books, 2 ID Lace, 3 Uniform

            if (name.Length == 0) { ShowWarning("Please enter the product name."); return; }
            if (categoryId < 1) { ShowWarning("Please choose a category."); return; }
            if (description.Length == 0) { ShowWarning("Please enter a description."); return; }
            if (price <= 0) { ShowWarning("The price must be more than zero."); return; }

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    using (MySqlCommand check = new MySqlCommand(
                        "SELECT COUNT(*) FROM product WHERE product_name = @name AND product_id <> @id", conn))
                    {
                        check.Parameters.AddWithValue("@name", name);
                        check.Parameters.AddWithValue("@id", loadedProductId);

                        if (Convert.ToInt64(check.ExecuteScalar()) > 0)
                        {
                            ShowWarning("Another product already has this name.");
                            return;
                        }
                    }

                    // A new picture is copied into the images folder; otherwise the current one is kept.
                    string newImagePath = null;
                    if (selectedImagePath.Length > 0)
                        newImagePath = ProductImages.SaveProductImage(loadedProductId, selectedImagePath);

                    // The stock status is not written: the database works it out from stock_qty.
                    using (MySqlCommand update = new MySqlCommand(
                        @"UPDATE product
                  SET product_name = @name, description = @desc,
                      price = @price, category_id = @cat, stock_qty = @qty" +
                        (newImagePath != null ? ", product_img = @img" : "") +
                        @" WHERE product_id = @id", conn))
                    {
                        update.Parameters.AddWithValue("@name", name);
                        update.Parameters.AddWithValue("@desc", description);
                        update.Parameters.AddWithValue("@price", price);
                        update.Parameters.AddWithValue("@cat", categoryId);
                        update.Parameters.AddWithValue("@qty", quantity);
                        update.Parameters.AddWithValue("@id", loadedProductId);
                        if (newImagePath != null)
                            update.Parameters.AddWithValue("@img", newImagePath);
                        update.ExecuteNonQuery();
                    }

                    // Back in stock after being out of stock: alert the students who pressed Notify Me.
                    if (loadedQuantity == 0 && quantity > 0)
                    {
                        using (MySqlCommand notify = new MySqlCommand(
                            @"UPDATE notification_subscription
                      SET status = 'SENT', notified_at = NOW()
                      WHERE product_id = @id AND status = 'PENDING'", conn))
                        {
                            notify.Parameters.AddWithValue("@id", loadedProductId);
                            notify.ExecuteNonQuery();
                        }
                    }
                }

                MessageBox.Show("Product \"" + name + "\" was updated.", "HiveStock",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.DialogResult = DialogResult.OK;   // tells the admin window to refresh
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not update the product: " + ex.Message,
                    "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ShowWarning(string message)
        {
            MessageBox.Show(message, "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}